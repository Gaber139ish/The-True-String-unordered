#include <bits/stdc++.h>
using namespace std;
using u64 = unsigned long long;
u64 g(u64 m, u64 n){ return 4 + 3*m + 3*n + 2*m*n; }
int main(int argc, char** argv){
    int M = argc>1?stoi(argv[1]):300;
    int N = argc>2?stoi(argv[2]):M;
    unordered_map<u64,int> seen;
    for(int m=0;m<=M;++m) for(int n=m;n<=N;++n) ++seen[g(m,n)];
    u64 maxv=0; for(auto &p:seen) maxv=max(maxv,p.first);
    vector<unsigned int> T(maxv+1);
    for(auto &p:seen) T[p.first] = (p.second==1 ? (unsigned int)p.first : 0);
    auto is_prime = [](u64 x)->bool{
        if(x<2) return false;
        u64 small[]={2,3,5,7,11,13,17,19,23,29};
        for(u64 pp:small) if(x==pp) return true;
        if(x%2==0) return false;
        u64 r = sqrt((long double)x);
        for(u64 i=3;i<=r;i+=2) if(x%i==0) return false;
        return true;
    };
    size_t cnt=0; for(u64 k=2;k<=maxv;++k) if(T[k]==k && is_prime(k)) ++cnt;
    cout<<"max="<<maxv<<" primes_in_T="<<cnt<<"\n";
    return 0;
}