use std::collections::HashMap;
fn g(m:u64,n:u64)->u64{4 + 3*m + 3*n + 2*m*n}
fn is_prime(n:u64)->bool{
    if n<2 { return false; }
    let small=[2u64,3,5,7,11,13,17,19,23,29];
    for &p in &small { if n==p { return true; } if n%p==0 { return false; } }
    if n%2==0 { return false; }
    let r = (n as f64).sqrt() as u64;
    let mut i=3u64;
    while i<=r { if n%i==0 { return false; } i+=2; }
    true
}
fn main(){
    let args: Vec<String> = std::env::args().collect();
    let M = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(300u64);
    let N = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(M);
    let mut seen: HashMap<u64,u32> = HashMap::new();
    for m in 0..=M { for n in m..=N { *seen.entry(g(m,n)).or_insert(0) += 1; } }
    let maxv = *seen.keys().max().unwrap_or(&0u64);
    let mut cnt = 0usize;
    for (&k,&c) in &seen { if c==1 && is_prime(k) { cnt += 1; } }
    println!(\"max={} primes_in_T={}\", maxv, cnt);
}