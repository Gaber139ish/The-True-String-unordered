True String Project Package

This package contains:
- paper.tex (expanded LaTeX)
- references.bib
- code/ (Python, C++, Rust)
- notebook/ (analysis notebook)
- outputs/ (sample CSVs)
- Dockerfile

Run the Python script:
    python3 code/true_string_unordered.py --M 500 --N 500 --state-file outputs/state.pkl

To compile the LaTeX file locally:
    pdflatex paper.tex && bibtex paper && pdflatex paper.tex && pdflatex paper.tex
